#!/usr/bin/env python3
"""
Test Pick-and-Place Verticale: muove il pedone bianco da e2 (white_pawn_4) a e4
mantenendo l'end-effector 100% parallelo all'asse Z del pezzo (Roll=pi, Pitch=0, Yaw=pi/2)
per non urtare i pezzi adiacenti.
Include il tracking cinematico della presa (grasp attachment) tra le dita della pinza e il pezzo.
"""
import time
import math
import subprocess
import numpy as np
import PyKDL

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from sensor_msgs.msg import JointState
from builtin_interfaces.msg import Duration
from ros_gz_interfaces.srv import SetEntityPose
from urdf_parser_py.urdf import URDF

from spawn_utils import get_chessboard_world_pose


def urdf_pose_to_kdl_frame(origin):
    if origin is None:
        return PyKDL.Frame()
    xyz = origin.xyz if origin.xyz else [0.0, 0.0, 0.0]
    rpy = origin.rpy if origin.rpy else [0.0, 0.0, 0.0]
    return PyKDL.Frame(
        PyKDL.Rotation.RPY(rpy[0], rpy[1], rpy[2]),
        PyKDL.Vector(xyz[0], xyz[1], xyz[2])
    )


class PickPlaceE2E4Node(Node):
    def __init__(self):
        super().__init__(
            'test_pick_place_e2e4',
            parameter_overrides=[rclpy.parameter.Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)]
        )
        self.get_logger().info('🤖 Inizializzazione nodo Pick & Place Verticale (e2 -> e4) [use_sim_time=True]...')

        # Costruzione catena cinematica fino al centro di presa tra le dita (tool0 + 0.225m lungo Z)
        self.build_kinematic_chain()
        self.fk_solver = PyKDL.ChainFkSolverPos_recursive(self.chain)
        self.ik_vel_solver = PyKDL.ChainIkSolverVel_pinv(self.chain)
        self.ik_solver = PyKDL.ChainIkSolverPos_NR_JL(
            self.chain, self.q_min_kdl, self.q_max_kdl,
            self.fk_solver, self.ik_vel_solver, 400, 1e-5
        )

        # Orientamento 100% VERTICALE: asse Z pinza antiparallelo all'asse Z del pezzo
        self.vert_rot = PyKDL.Rotation.RPY(math.pi, 0.0, math.pi / 2.0)

        # Configurazione Home Verticale sopra il centro scacchiera
        self.home_q = [0.335, 0.771, -2.282, -0.377, 2.302, 1.113]
        self.current_q = list(self.home_q)

        # Stato aggancio pezzo (Grasp Attachment)
        self.attached_piece = None
        self.piece_z_offset = -0.024  # La base del pedone sta 24mm sotto il centro di presa dei polpastrelli

        # Subscriber stato giunti reale da Gazebo
        self.js_received = False
        self.js_sub = self.create_subscription(JointState, '/joint_states', self.js_callback, 10)

        # Client servizio SetEntityPose per solidarizzare il pezzo afferrato con le dita durante il trasporto
        self.set_pose_client = self.create_client(SetEntityPose, '/world/empty/set_pose')

        # Action Clients per braccio e pinza
        self.arm_client = ActionClient(self, FollowJointTrajectory, '/arm_controller/follow_joint_trajectory')
        self.gripper_client = ActionClient(self, FollowJointTrajectory, '/gripper_controller/follow_joint_trajectory')

    def js_callback(self, msg: JointState):
        name_to_pos = dict(zip(msg.name, msg.position))
        if all(j in name_to_pos for j in self.joint_names):
            self.current_q = [name_to_pos[j] for j in self.joint_names]
            self.js_received = True

            # Se un pezzo è stretto tra le dita, aggiorna in tempo reale la sua posa solidale al TCP!
            if self.attached_piece is not None and self.set_pose_client.service_is_ready():
                now_mono = time.monotonic()
                if not hasattr(self, '_last_pose_update') or (now_mono - self._last_pose_update) >= 0.08:
                    self._last_pose_update = now_mono
                    q_kdl = PyKDL.JntArray(self.num_joints)
                    for i in range(self.num_joints):
                        q_kdl[i] = self.current_q[i]
                    f_tcp = PyKDL.Frame()
                    self.fk_solver.JntToCart(q_kdl, f_tcp)

                    req = SetEntityPose.Request()
                    req.entity.name = self.attached_piece
                    req.pose.position.x = float(f_tcp.p.x())
                    req.pose.position.y = float(f_tcp.p.y())
                    req.pose.position.z = float(f_tcp.p.z() + 1.0 + self.piece_z_offset)
                    req.pose.orientation.x = 0.0
                    req.pose.orientation.y = 0.0
                    req.pose.orientation.z = math.sin(-math.pi / 4.0)
                    req.pose.orientation.w = math.cos(-math.pi / 4.0)
                    self.set_pose_client.call_async(req)

    def build_kinematic_chain(self):
        urdf_str = subprocess.check_output(
            "xacro $(ros2 pkg prefix robot_arms)/share/robot_arms/urdf/uclv_right_ur5e.urdf.xacro",
            shell=True
        ).decode('utf-8')
        robot = URDF.from_xml_string(urdf_str)

        parent_map = {j.child: j for j in robot.joints}
        curr = "tool0"
        joints_in_chain = []
        while curr != "world":
            j = parent_map[curr]
            joints_in_chain.append(j)
            curr = j.parent
        joints_in_chain.reverse()

        self.chain = PyKDL.Chain()
        self.joint_names = []
        q_min, q_max = [], []

        for j in joints_in_chain:
            f = urdf_pose_to_kdl_frame(j.origin)
            self.chain.addSegment(
                PyKDL.Segment(j.name + "_orig", PyKDL.Joint(j.name + "_fix", PyKDL.Joint.Fixed), f)
            )
            if j.type in ("revolute", "continuous"):
                axis = PyKDL.Vector(j.axis[0], j.axis[1], j.axis[2]) if j.axis else PyKDL.Vector(0, 0, 1)
                joint = PyKDL.Joint(j.name, PyKDL.Vector(0, 0, 0), axis, PyKDL.Joint.RotAxis)
                self.chain.addSegment(PyKDL.Segment(j.child, joint, PyKDL.Frame()))
                self.joint_names.append(j.name)
                q_min.append(j.limit.lower if j.limit else -2 * math.pi)
                q_max.append(j.limit.upper if j.limit else 2 * math.pi)

        # TCP = centro di presa dei polpastrelli della pinza Robotiq Hand-E (+0.225m da tool0)
        self.chain.addSegment(
            PyKDL.Segment("tcp", PyKDL.Joint("tcp_fixed", PyKDL.Joint.Fixed), PyKDL.Frame(PyKDL.Vector(0, 0, 0.225)))
        )

        self.num_joints = len(self.joint_names)
        self.q_min_kdl = PyKDL.JntArray(self.num_joints)
        self.q_max_kdl = PyKDL.JntArray(self.num_joints)
        for i in range(self.num_joints):
            self.q_min_kdl[i] = q_min[i]
            self.q_max_kdl[i] = q_max[i]

    def solve_ik_vertical(self, x, y, z, seed_q=None):
        target = PyKDL.Frame(self.vert_rot, PyKDL.Vector(x, y, z))
        q_init = PyKDL.JntArray(self.num_joints)
        q_out = PyKDL.JntArray(self.num_joints)

        seeds = ([seed_q] if seed_q is not None else []) + [self.current_q, self.home_q]
        for s in seeds:
            for i in range(self.num_joints):
                q_init[i] = s[i]
            if self.ik_solver.CartToJnt(q_init, target, q_out) >= 0:
                return [q_out[i] for i in range(self.num_joints)]
        raise RuntimeError(f"Impossibile risolvere IK verticale per ({x:.3f}, {y:.3f}, {z:.3f})")

    def square_to_robot_frame(self, row, col):
        cx, cy, cz_gz, cb_yaw = get_chessboard_world_pose()
        SQUARE_SIZE = 0.057
        A1_X = 0.1995
        A1_Y = 0.1995

        lx = A1_X - (col * SQUARE_SIZE)
        ly = A1_Y - (row * SQUARE_SIZE)

        gx = cx + (lx * math.cos(cb_yaw)) - (ly * math.sin(cb_yaw))
        gy = cy + (lx * math.sin(cb_yaw)) + (ly * math.cos(cb_yaw))

        board_top_z = (cz_gz - 1.0) + 0.00625
        return gx, gy, board_top_z

    def move_arm_cartesian_vertical(self, x, y, z_start, z_end, duration_sec=2.5, num_steps=12):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = list(self.joint_names)

        zs = np.linspace(z_start, z_end, num_steps)
        last_q = list(self.current_q)

        for idx, z_val in enumerate(zs):
            q_sol = self.solve_ik_vertical(x, y, float(z_val), seed_q=last_q)
            last_q = q_sol
            pt = JointTrajectoryPoint()
            pt.positions = [float(v) for v in q_sol]
            t = duration_sec * (idx + 1) / num_steps
            sec = int(t)
            nanosec = int((t - sec) * 1e9)
            pt.time_from_start = Duration(sec=sec, nanosec=nanosec)
            goal.trajectory.points.append(pt)

        self.send_and_wait(self.arm_client, goal, duration_sec + 0.5)
        self.current_q = last_q

    def move_arm_joint(self, q_target, duration_sec=2.5):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = list(self.joint_names)

        pt = JointTrajectoryPoint()
        pt.positions = [float(v) for v in q_target]
        sec = int(duration_sec)
        nanosec = int((duration_sec - sec) * 1e9)
        pt.time_from_start = Duration(sec=sec, nanosec=nanosec)
        goal.trajectory.points.append(pt)

        self.send_and_wait(self.arm_client, goal, duration_sec + 0.5)
        self.current_q = list(q_target)

    def set_gripper(self, stroke_val, duration_sec=1.0):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = ['hande_joint', 'hande_base_to_hande_jaw2_link']

        pt = JointTrajectoryPoint()
        pt.positions = [float(stroke_val), float(stroke_val)]
        sec = int(duration_sec)
        nanosec = int((duration_sec - sec) * 1e9)
        pt.time_from_start = Duration(sec=sec, nanosec=nanosec)
        goal.trajectory.points.append(pt)

        self.send_and_wait(self.gripper_client, goal, duration_sec + 0.4)

    def send_and_wait(self, client: ActionClient, goal, timeout_sec):
        if not client.wait_for_server(timeout_sec=5.0):
            raise RuntimeError("Action server del controller non disponibile! Assicurati che Gazebo sia avviato.")
        future = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        goal_handle = future.result()
        if not goal_handle or not goal_handle.accepted:
            raise RuntimeError("Goal rifiutato dal controller!")
        res_future = goal_handle.get_result_async()
        # Attende il completamento REALE della traiettoria in Gazebo (anche se il Real Time Factor è < 100%)
        rclpy.spin_until_future_complete(self, res_future, timeout_sec=timeout_sec * 8.0 + 10.0)

    def execute_e2_to_e4(self):
        self.get_logger().info('⏳ Attesa stato giunti e server controller...')
        t0 = time.time()
        while not self.js_received and (time.time() - t0) < 5.0:
            rclpy.spin_once(self, timeout_sec=0.1)

        # Calcolo coordinate e2 (row=1, col=4 -> white_pawn_4) ed e4 (row=3, col=4)
        e2_x, e2_y, board_z = self.square_to_robot_frame(row=1, col=4)
        e4_x, e4_y, _ = self.square_to_robot_frame(row=3, col=4)

        hover_z = board_z + 0.160   # 160 mm sopra la scacchiera (ben sopra il Re alto 95 mm!)
        grasp_z = board_z + 0.024   # 24 mm sopra la scacchiera (colletto del pedone alto 45 mm)

        # Assicuriamoci che il pedone white_pawn_4 sia nella sua casella di partenza e2 (nel caso il test venga rieseguito!)
        if self.set_pose_client.wait_for_service(timeout_sec=2.0):
            req_reset = SetEntityPose.Request()
            req_reset.entity.name = 'white_pawn_4'
            req_reset.pose.position.x = float(e2_x)
            req_reset.pose.position.y = float(e2_y)
            req_reset.pose.position.z = float(board_z + 1.0 + 0.001)
            req_reset.pose.orientation.z = math.sin(-math.pi / 4.0)
            req_reset.pose.orientation.w = math.cos(-math.pi / 4.0)
            self.set_pose_client.call_async(req_reset)
        self.get_logger().info(f'📍 Coordinate Casella e4 (arrivo):   X={e4_x:.4f}, Y={e4_y:.4f}, Z_board={board_z:.4f}')

        # 1. Apertura pinza e posizionamento in Home Verticale
        self.get_logger().info('1️⃣ Apertura pinza e allineamento in Home Verticale...')
        self.set_gripper(0.012, duration_sec=0.8)
        self.move_arm_joint(self.home_q, duration_sec=1.5)

        # 2. Spostamento sopra e2 a quota di sicurezza (Hover Z = +160 mm, pinza 100% verticale)
        self.get_logger().info('2️⃣ Approccio sopra e2 (Hover Z = +160 mm, orientamento 100% verticale)...')
        q_hover_e2 = self.solve_ik_vertical(e2_x, e2_y, hover_z)
        self.move_arm_joint(q_hover_e2, duration_sec=1.8)

        # 3. Discesa cartesiana puramente VERTICALE su e2 (da +160 mm a +24 mm) senza toccare i pezzi vicini
        self.get_logger().info('3️⃣ Discesa cartesiana VERTICALE pura su e2 (da +160 mm a +24 mm)...')
        self.move_arm_cartesian_vertical(e2_x, e2_y, hover_z, grasp_z, duration_sec=1.8, num_steps=10)

        # 4. Chiusura simmetrica pinza sul pedone in e2 e aggancio presa
        self.get_logger().info('4️⃣ Chiusura pinza sul pedone in e2 (white_pawn_4)...')
        self.set_gripper(-0.002, duration_sec=0.8)
        self.attached_piece = 'white_pawn_4'

        # 5. Salita cartesiana puramente VERTICALE da e2 (da +24 mm a +160 mm)
        self.get_logger().info('5️⃣ Sollevamento cartesiano VERTICALE puro da e2 (fino a +160 mm)...')
        self.move_arm_cartesian_vertical(e2_x, e2_y, grasp_z, hover_z, duration_sec=1.8, num_steps=10)

        # 6. Traslazione orizzontale ad alta quota da e2 a e4 (a Z = +160 mm, sopra tutti i pezzi)
        self.get_logger().info('6️⃣ Trasporto aereo sopra la casella e4 (a quota costante +160 mm)...')
        q_hover_e4 = self.solve_ik_vertical(e4_x, e4_y, hover_z, seed_q=self.current_q)
        self.move_arm_joint(q_hover_e4, duration_sec=1.6)

        # 7. Discesa cartesiana puramente VERTICALE su e4 (da +160 mm a +25 mm)
        self.get_logger().info('7️⃣ Discesa cartesiana VERTICALE pura sulla casella e4...')
        self.move_arm_cartesian_vertical(e4_x, e4_y, hover_z, grasp_z + 0.001, duration_sec=1.8, num_steps=10)

        # 8. Rilascio del pedone in e4 (sgancio e apertura pinza)
        self.get_logger().info('8️⃣ Rilascio del pedone in e4...')
        self.attached_piece = None
        if self.set_pose_client.service_is_ready():
            req = SetEntityPose.Request()
            req.entity.name = 'white_pawn_4'
            req.pose.position.x = float(e4_x)
            req.pose.position.y = float(e4_y)
            req.pose.position.z = float(board_z + 1.0 + 0.001)
            req.pose.orientation.z = math.sin(-math.pi / 4.0)
            req.pose.orientation.w = math.cos(-math.pi / 4.0)
            self.set_pose_client.call_async(req)
        self.set_gripper(0.012, duration_sec=0.8)

        # 9. Risalita cartesiana puramente VERTICALE da e4 (da +25 mm a +160 mm)
        self.get_logger().info('9️⃣ Risalita cartesiana VERTICALE di disimpegno da e4...')
        self.move_arm_cartesian_vertical(e4_x, e4_y, grasp_z + 0.001, hover_z, duration_sec=1.5, num_steps=8)

        # 10. Ritorno in posa Home Verticale
        self.get_logger().info('🔟 Ritorno in posa Home Verticale...')
        self.move_arm_joint(self.home_q, duration_sec=1.5)

        self.get_logger().info('✅ Mossa e2 -> e4 completata con successo!')


def main(args=None):
    rclpy.init(args=args)
    node = PickPlaceE2E4Node()
    try:
        node.execute_e2_to_e4()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
